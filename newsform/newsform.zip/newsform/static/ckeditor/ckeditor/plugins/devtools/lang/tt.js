﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","tt",{title:"Элемент тасвирламасы",dialogName:"Диалог тәрәзәсе исеме",tabName:"Өстәмә бит исеме",elementId:"Элемент идентификаторы",elementType:"Элемент төре"});